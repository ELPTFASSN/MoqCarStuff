# ---------------------------------------------------------
# The purpose of this Caller Function is to make a call to
# Run VSTest.ps1 with specific inputs.

Clear-Host

$path = 'C:\Usage\Source\JoeWare\Main\HowToMoq\SF_MSTest_Car_UT\'

$specificArguments = '/Platform:x86'

$runDate = Get-Date -format "yyyy_MM_dd_HH_mm_sss"

$outputFile = "C:\Usage\TestOutput\Drive\Drive_$runDate.txt"

$testRunner = "C:\Usage\Scripting\Powershell\UnitTesting\Functional\Run_VSTest.ps1"

$testContainer = "C:\Usage\Source\JoeWare\Main\HowToMoq\SF_MSTest_Car_UT\bin\Debug\SF_MSTest_Car_UT.dll"

# ----------
# Run MSTest

. $testRunner $path $testContainer $outputFile $specificArguments

# --------
# Clean up

if($runDate) { Clear-Variable runDate }
if($outputFile) { Clear-Variable outputFile }
if($testRunner) { Clear-Variable testRunner }
if($testContainer) { Clear-Variable testContainer }
if($specificArguments) { Clear-Variable specificArguments }