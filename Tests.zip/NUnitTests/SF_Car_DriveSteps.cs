﻿
using Moq;
using CarStuff;
using TechTalk.SpecFlow;
using NUnit.Framework;

// --------------------------------------------------------
// The SF_ in the name of this class represents SpecFlow. 

namespace NUnitTests
{
    [Binding]
    public class SF_Car_DriveSteps
    {
        int resp = 0;
        private const int SPEED_UP = 1;
        private const int SLOW_DOWN = -1;
        private const int STAT_CONSTANT = 0;
        private Mock<ICar> m_car = new Mock<ICar>();

        // ------------------------------------------------

        [Given(@"I enter the speed that I am driving which is under the speed limit")]
        public void GivenIEnterTheSpeedThatIAmDrivingWhichIsUnderTheSpeedLimit()
        {
            m_car.Setup(c => c.GetSpeed()).Returns(20);
        }

        // ------------------------------------------------

        [When(@"I Drive the car")]
        public void WhenIDriveTheCar()
        {
            Driver sut = new Driver(m_car.Object, 65);
            resp = sut.Drive();
        }

        // ------------------------------------------------
        
        [Then(@"I am prompted to speed up")]
        public void ThenIAmPromptedToSpeedUp()
        {
            Assert.AreEqual(SPEED_UP, resp);
        }
    }
}
