﻿using System;

using Moq;
using CarStuff;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CarStuff_UT
{
    // ----------------------------------------------------
    /// <summary>
    ///     This Test Class is one example of how to use
    ///     MOQ to isolate the System Under Test (SUT)
    ///     from external dependencies.
    /// </summary>

    [TestClass]
    public class Driver_UT
    {
        private Mock<ICar> m_car;

        public Driver_UT()
        { }

        private TestContext testContextInstance;

        // ------------------------------------------------
        /// <summary>
        ///     Gets or sets the test context which provides
        ///     information about and functionality for the current test run.
        ///</summary>

        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes

        // ------------------------------------------------------------------------
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        //
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        //
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //

        // ------------------------------------------------
        // Use TestInitialize to run code before running 
        // each test 

        [TestInitialize()]
        public void MyTestInitialize()
        {
            // ------------------------
            // Create a MOQ Car object.

            m_car = new Mock<ICar>();
        }

        // ---------------------------------------------------
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        
        #endregion

        // ------------------------------------------------
        // In order to us the DataRow attribute, we must 
        // remove the reference to 
        // Microsoft.VisualStudio.TestTools.UnitTesting.dll
        // and use Nuget to add back in
        // Microsoft.VisualStudio.TestPlatform.TestFramework.dll
        // This library is currently in Preview

        [TestMethod, TestCategory("Drive"), TestCategory("Happy")]
        [DataRow(/*speed*/ 40, /*maxAllowed*/ 55, /*expectedResult*/  1)] // Speed Up 
        [DataRow(/*speed*/ 45, /*maxAllowed*/ 55, /*expectedResult*/  1)] // Speed Up
        [DataRow(/*speed*/ 60, /*maxAllowed*/ 55, /*expectedResult*/ -1)] // Slow Down
        [DataRow(/*speed*/ 56, /*maxAllowed*/ 55, /*expectedResult*/ -1)] // Slow Down
        [DataRow(/*speed*/ 55, /*maxAllowed*/ 55, /*expectedResult*/  0)] // Maintain Speed
        [DataRow(/*speed*/ 55, /*maxAllowed*/ 55, /*expectedResult*/  0)] // Maintain Speed 
        public void Drive2(int speed, int maxAllowed, int expectedResult)
        {
            // -----------------------------------------
            // When GetSpeed() is called on the Moq Car,
            // return whatever the local method GetSpeed() returns.
            // (Control what car.GetSpeed() returns)

            m_car.Setup(c => c.GetSpeed()).Returns(speed);

            // -----------------------------------------
            // Use the Moq Car in the Driver Constructor

            Driver driver = new Driver(m_car.Object, maxAllowed);

            // -------------------------------------------
            // driver.Drive will make a call to GetSpeed()
            // (On the Mocked Object)
            //  0: Maintain Speed
            //  1: Speed Up
            // -1: Slow Down

            var resp = driver.Drive();

            // -----------------------------------------------------
            // Stipulate that GetSpeed is only called once per test.

            m_car.Verify(c => c.GetSpeed(), Times.Exactly(1));

            Assert.AreEqual(expectedResult, resp);
        }

        // ------------------------------------------------
        /// <summary>
        ///     SUT: Dirver.Drive
        /// </summary>

        [DeploymentItem("TestData\\Car_TD.xml"),
         DataSource("Microsoft.VisualStudio.TestTools.DataSource.XML",
                    "|DataDirectory|\\Car_TD.xml",
                    "Drive",
                    DataAccessMethod.Sequential),
        TestMethod, TestCategory("Drive"), TestCategory("Happy")]
        public void Drive()
        {
            int sxpectedResult = Convert.ToInt32(TestContext.DataRow["ExpectedResult"]);
            int maxAllowedSpeed = Convert.ToInt32(TestContext.DataRow["MaxAllowedSpeed"]);

            // -----------------------------------------
            // When GetSpeed() is called on the Moq Car,
            // return whatever the local method GetSpeed() returns.
            // (Control what m_car.GetSpeed() returns)

            m_car.Setup(c => c.GetSpeed()).Returns(GetMoqSpeed());

            // -----------------------------------------
            // Use the Moq Car in the Driver Constructor

            Driver driver = new Driver(m_car.Object, maxAllowedSpeed);

            // -------------------------------------------
            // driver.Drive will make a call to GetSpeed()
            // (On the Mocked Object)

            var resp = driver.Drive();

            // --------------------------------------------
            // Stipulate that GetSpeed is only called once.

            m_car.Verify(c => c.GetSpeed(), Times.Exactly(1));

            Assert.AreEqual(sxpectedResult, resp);
        }

        // ------------------------------------------------

        [DeploymentItem("TestData\\Car_TD.xml"),
         DataSource("Microsoft.VisualStudio.TestTools.DataSource.XML",
                    "|DataDirectory|\\Car_TD.xml",
                    "Options",
                    DataAccessMethod.Sequential),
        TestMethod, TestCategory("Options"), TestCategory("Happy")]
        public void Options()
        {
            string color = Convert.ToString(TestContext.DataRow["Color"]);
            string tireSet = Convert.ToString(TestContext.DataRow["TireSet"]);
            bool sportsPackage = Convert.ToBoolean(TestContext.DataRow["SportsPackage"]);
            int maxAllowedSpeed = Convert.ToInt32(TestContext.DataRow["MaxAllowedSpeed"]);

            // -----------------------------------------
            // When GetOptions() is called on the Moq Car,
            // return whatever the local method GetOptions() returns.
            // (Control what car.GetOptions() returns)
            // Use a local method to keep from building the 
            // Moq Return object inline.

            m_car.Setup(c => c.Options).Returns(GetMoqOptions());

            // -----------------------------------------
            // Use the Moq Car in the Driver Constructor

            Driver driver = new Driver(m_car.Object, maxAllowedSpeed);

            // --------------------------------------------
            // These properties of Driver make calls to the 
            // OptionsPackage of the Car object.

            Assert.AreEqual(color, driver.CarColor);
            Assert.AreEqual(tireSet.ToString(), driver.TireOption);
            Assert.AreEqual(sportsPackage, driver.PurchasedSportsPackage);
        }

        // ------------------------------------------------
        /// <summary>
        ///     Control the return of Moq'ed Car.GetSpeed()
        /// </summary>
        /// <returns></returns>

        private int GetMoqSpeed()
        {
            // ------------------------------------------------------------
            // The TestContext will be set for each cycle through the test.
            // Since we are using an XML file to store our input data,
            // Each node for the test, which itself calls this method,
            // will use the current input data node from that XML file.

            return Convert.ToInt32(TestContext.DataRow["Speed"]);
        }

        // ------------------------------------------------
        /// <summary>
        ///     Control the contents of the Moq'ed 
        ///     Car.OptionsPackage object.
        /// </summary>
        /// <returns></returns>

        private OptionsPackage GetMoqOptions()
        {
            // ------------------------------------------------------------
            // The TestContext will be set for each cycle through the test.
            // Since we are using an XML file to store our input data,
            // Each node for the test, which itself calls this method,
            // will use the current input data node from that XML file.

            return new OptionsPackage()
            {
                SportsPackage = Convert.ToBoolean(TestContext.DataRow["SportsPackage"]),
                Tires = (TireSet)Enum.Parse(typeof(TireSet), Convert.ToString(TestContext.DataRow["TireSet"])),
                Color = (ConsoleColor)Enum.Parse(typeof(ConsoleColor), Convert.ToString(TestContext.DataRow["Color"]))
            };
        }
    }
}
