﻿
namespace CarStuff
{
    public interface ICar
    {
        OptionsPackage Options {set; get;}
        void Drive();
        int GetSpeed();
    }
}
